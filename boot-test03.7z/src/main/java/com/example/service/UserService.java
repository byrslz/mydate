package com.example.service;

import com.example.pojo.User;

import java.util.List;

public interface UserService {
    boolean add(User user);
    boolean del(Integer uid);
    boolean update(User user);
    User findId(Integer uid);
    List<User> allFind();
}
