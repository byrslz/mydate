package com.example.controller;

import com.example.pojo.User;
import com.example.returnjson.UserFindJson;
import com.example.returnjson.UserJson;
import com.example.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    @PostMapping("/add")
    public UserJson add(@RequestBody User user){
        String info="添加失败";
        String isOk="false";
        boolean add = userService.add(user);
        if (add==true){
            info="添加成功";
            isOk="true";
        }
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo(info);
        userJson.setIsOk(isOk);
        return userJson;
    }

    @DeleteMapping("{uid}")
    public UserJson del(@PathVariable int uid){
        String info="删除失败";
        String isOk="false";
        boolean del= userService.del(uid);
        if (del==true){
            info="删除成功";
            isOk="true";
        }
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo(info);
        userJson.setIsOk(isOk);
        return userJson;
    }

    @PutMapping("/update")
    public UserJson update(@RequestBody User user){
        String info="修改失败";
        String isOk="false";
        boolean update=userService.update(user);
        if (update==true){
            info="修改成功";
            isOk="true";
        }
        UserJson userJson=new UserJson();
        userJson.setStatue(200);
        userJson.setInfo(info);
        userJson.setIsOk(isOk);
        return userJson;
    }
    @GetMapping("{uid}")
    public UserFindJson find(@PathVariable int uid){
        User user=userService.findId(uid);
        UserFindJson userFindJson=new UserFindJson();
        userFindJson.setInfo("查询信息：");
        userFindJson.setStatue(200);
        userFindJson.setUser(user);
        return userFindJson;
    }

    @GetMapping("/findAll")
    public List<User> findAll(){
        return userService.allFind();
    }
}
