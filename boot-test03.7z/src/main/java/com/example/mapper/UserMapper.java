package com.example.mapper;

import com.example.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {
    int add(@Param(value = "user") User user);
    int del(Integer uid);
    int update(@Param(value = "user")User user);
    User findById(Integer uid);
    List<User> findAll();
}
